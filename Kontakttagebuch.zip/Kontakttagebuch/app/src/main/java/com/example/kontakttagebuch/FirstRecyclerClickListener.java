package com.example.kontakttagebuch;

public interface FirstRecyclerClickListener {
    void onItemClick(int position);
}
